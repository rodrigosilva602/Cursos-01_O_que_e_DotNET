﻿Module Module1

    Sub Main()

        Console.WriteLine("Alô Mundo!")
        Console.ReadKey()

    End Sub

End Module
